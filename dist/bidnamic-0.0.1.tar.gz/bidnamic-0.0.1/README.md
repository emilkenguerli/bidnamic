# bidnamic

## Usage

Run main.py which will create a python daemon that monitors the data directory, when you place CSV files in this directory it will generate new CSV files in the processed\GBP\search_terms directory