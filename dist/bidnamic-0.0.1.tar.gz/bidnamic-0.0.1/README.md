# bidnamic

## Usage

Run main.py which will create a python daemon that monitors the data/ directory, when you place CSV files in this directory it will generate new CSV files in the processed/GBP/search_terms/ directory

## Packaging and Distribution

Distribution packages can be found in the dist/ directory. These are archives that are uploaded to the Python Package Index and can be installed by pip.